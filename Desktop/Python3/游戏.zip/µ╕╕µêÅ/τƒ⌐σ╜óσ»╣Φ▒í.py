import pygame
hero_rect = pygame.Rect((140, 120, 20, 30))
print(hero_rect.x)
print(hero_rect.y)
print(hero_rect.size)
print(hero_rect.w, hero_rect.h)
print(hero_rect.centerx, hero_rect.centery)